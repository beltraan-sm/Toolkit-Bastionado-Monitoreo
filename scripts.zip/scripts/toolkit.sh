!/bin/bash
# ============================================================
#  toolkit.sh — Menú principal del Linux Security Toolkit
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

TOOLS_DIR="$(dirname "$0")/tools"

# ============================================================
# Comprueba que el script existe y tiene permisos
# ============================================================
check_tool() {
    local tool="$1"
    if [ ! -f "$TOOLS_DIR/$tool" ]; then
        echo -e "${RED}  ✘ No encontrado: $TOOLS_DIR/$tool${NC}"
        return 1
    fi
    chmod +x "$TOOLS_DIR/$tool"
    return 0
}

# ============================================================
# Pantalla de bienvenida
# ============================================================
show_banner() {
    clear
    echo -e "${BLUE}${BOLD}"
    echo "  ██╗     ██╗███╗   ██╗██╗   ██╗██╗  ██╗"
    echo "  ██║     ██║████╗  ██║██║   ██║╚██╗██╔╝"
    echo "  ██║     ██║██╔██╗ ██║██║   ██║ ╚███╔╝ "
    echo "  ██║     ██║██║╚██╗██║██║   ██║ ██╔██╗ "
    echo "  ███████╗██║██║ ╚████║╚██████╔╝██╔╝ ██╗"
    echo "  ╚══════╝╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝"
    echo -e "${NC}"
    echo -e "${CYAN}  🛡️  Linux Security Toolkit — Ubuntu Edition${NC}"
    echo -e "${CYAN}  Sistema: $(hostname) | Usuario: $(whoami) | $(date '+%d/%m/%Y %H:%M')${NC}"
    echo ""
    echo -e "  ${YELLOW}─────────────────────────────────────────────${NC}"
}

# ============================================================
# Menú principal
# ============================================================
show_menu() {
    echo ""
    echo -e "  ${BOLD}Selecciona una herramienta:${NC}"
    echo ""
    echo -e "  ${GREEN}[1]${NC} Auitaria de los usuarios del sistema"
    echo -e "  ${GREEN}[2]${NC} Hardening de ssh"
    echo -e "  ${GREEN}[3]${NC} Auditoria del firewall"
    echo -e "  ${GREEN}[4]${NC} Monitoreo de logs"
    echo ""
    echo ""
    echo -e "  ${RED}[0]${NC} Salir"
    echo ""
    echo -e "  ${YELLOW}─────────────────────────────────────────────${NC}"
    echo ""
}

# ============================================================
# Ejecutar una herramienta con separador visual
# ============================================================
run_tool() {
    local tool_name="$1"
    local tool_file="$2"

    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}  ▶ Ejecutando: $tool_name${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""

    if check_tool "$tool_file"; then
        sudo "$TOOLS_DIR/$tool_file"
    fi

    echo ""
    echo -e "${YELLOW}  Pulsa ENTER para volver al menú...${NC}"
    read -r
}

# ============================================================
# Ejecutar todas las herramientas seguidas
# ============================================================
run_all() {
    echo ""
    echo -e "${CYAN}  Ejecutando todas las herramientas en secuencia...${NC}"
    echo ""

    run_tool "User Audit"     "user_audit.sh"
    run_tool "SSH Hardening"  "ssh_hardening.sh"
    run_tool "Firewall Audit" "firewall_audit.sh"
    run_tool "Log Monitor"    "log_monitor.sh"

    echo -e "${GREEN}  ✔ Todas las herramientas completadas.${NC}"
    echo -e "${GREEN}  Revisa los reportes en: evidences/${NC}"
    echo ""
    echo -e "${YELLOW}  Pulsa ENTER para volver al menú...${NC}"
    read -r
}


while true; do
    show_banner
    show_menu

    read -rp "  → Introduce tu opción: " option

    case $option in
        1) run_tool "User Audit"     "user_audit.sh"   ;;
        2) run_tool "SSH Hardening"  "ssh-hard.sh" ;;
        3) run_tool "Firewall Audit" "firewall_audit.sh" ;;
        4) run_tool "Log Monitor"    "ver-logs.sh"   ;;
        5) run_all ;;
        0)
            echo ""
            echo -e "  ${GREEN}Hasta luego. Revisa los reportes en evidences/${NC}"
            echo ""
            exit 0
            ;;
        *)
            echo -e "  ${RED}Opción no válida. Inténtalo de nuevo.${NC}"
            sleep 1
            ;;
    esac
done