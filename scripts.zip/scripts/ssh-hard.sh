#!/bin/bash
# ============================================================
# — Bastionado del servicio SSH
#  Compatible: Ubuntu 20.04 / 22.04 / 24.04
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

REPORT_DIR="$(dirname "$0")/../evidences"
REPORT_FILE="$REPORT_DIR/ssh_hardening_$(date +%Y%m%d_%H%M%S).txt"
SSH_CONFIG="/etc/ssh/sshd_config"
BACKUP_FILE="/etc/ssh/sshd_config.backup_$(date +%Y%m%d_%H%M%S)"

log() {
    echo -e "$1" | tee -a "$REPORT_FILE"
}


check_ssh() {
    log "\n${YELLOW}[1] COMPROBANDO SSH${NC}"
    log "------------------------------------------------------------"

    if ! command -v sshd &>/dev/null; then
        log "${RED}  ✘ SSH no está instalado. Instalando...${NC}"
        apt-get install -y openssh-server &>/dev/null
        log "${GREEN}  ✔ SSH instalado correctamente.${NC}"
    else
        log "${GREEN}  ✔ SSH encontrado: $(sshd -V 2>&1 | head -1)${NC}"
    fi
}


backup_config() {
    log "\n${YELLOW}[2] BACKUP DE CONFIGURACIÓN ORIGINAL${NC}"
    log "------------------------------------------------------------"

    cp "$SSH_CONFIG" "$BACKUP_FILE"
    log "${GREEN}  ✔ Backup guardado en: $BACKUP_FILE${NC}"
}


apply_hardening() {
    log "\n${YELLOW}[3] APLICANDO CONFIGURACIÓN SEGURA${NC}"
    log "------------------------------------------------------------"

    # Deshabilitar login como root
    # ¿Por qué? Si alguien adivina la contraseña de root, tiene control total.
    sed -i 's/^#*PermitRootLogin.*/PermitRootLogin no/' "$SSH_CONFIG"
    log "${GREEN}  ✔ PermitRootLogin → no${NC}"

    # Deshabilitar autenticación por contraseña vacía
    # ¿Por qué? Nadie debería poder entrar sin escribir nada.
    sed -i 's/^#*PermitEmptyPasswords.*/PermitEmptyPasswords no/' "$SSH_CONFIG"
    log "${GREEN}  ✔ PermitEmptyPasswords → no${NC}"

    # Limitar intentos de login a 3
    # ¿Por qué? Frena los ataques de fuerza bruta automatizados.
    sed -i 's/^#*MaxAuthTries.*/MaxAuthTries 3/' "$SSH_CONFIG"
    log "${GREEN}  ✔ MaxAuthTries → 3${NC}"

    # Desactivar reenvío X11
    # ¿Por qué? X11 forwarding abre un canal gráfico innecesario y peligroso.
    sed -i 's/^#*X11Forwarding.*/X11Forwarding no/' "$SSH_CONFIG"
    log "${GREEN}  ✔ X11Forwarding → no${NC}"

    # Establecer timeout de sesión inactiva (5 minutos)
    # ¿Por qué? Una sesión olvidada abierta es una puerta abierta.
    sed -i 's/^#*ClientAliveInterval.*/ClientAliveInterval 300/' "$SSH_CONFIG"
    sed -i 's/^#*ClientAliveCountMax.*/ClientAliveCountMax 0/' "$SSH_CONFIG"
    log "${GREEN}  ✔ Timeout de sesión inactiva → 5 minutos${NC}"

    # Usar solo protocolo SSH versión 2
    # ¿Por qué? SSHv1 tiene vulnerabilidades conocidas y está obsoleto.
    grep -q "^Protocol" "$SSH_CONFIG" || echo "Protocol 2" >> "$SSH_CONFIG"
    log "${GREEN}  ✔ Protocolo SSH → versión 2 únicamente${NC}"
}


verify_config() {
    log "\n${YELLOW}[4] VERIFICANDO CONFIGURACIÓN${NC}"
    log "------------------------------------------------------------"

    if sshd -t 2>/dev/null; then
        log "${GREEN}  ✔ Configuración válida, sin errores de sintaxis.${NC}"
        return 0
    else
        log "${RED}  ✘ Error en la configuración. Restaurando backup...${NC}"
        cp "$BACKUP_FILE" "$SSH_CONFIG"
        log "${YELLOW}  ✔ Backup restaurado. No se aplicaron cambios.${NC}"
        return 1
    fi
}

restart_ssh() {
    log "\n${YELLOW}[5] REINICIANDO SERVICIO SSH${NC}"
    log "------------------------------------------------------------"

    systemctl restart ssh
    sleep 2

    if systemctl is-active --quiet ssh; then
        log "${GREEN}  ✔ SSH reiniciado y activo correctamente.${NC}"
    else
        log "${RED}  ✘ SSH no arrancó. Restaurando backup...${NC}"
        cp "$BACKUP_FILE" "$SSH_CONFIG"
        systemctl restart ssh
        log "${YELLOW}  ✔ Backup restaurado.${NC}"
    fi
}


show_summary() {
    log "\n${YELLOW}[6] RESUMEN DE CONFIGURACIÓN APLICADA${NC}"
    log "------------------------------------------------------------"
    log "  PermitRootLogin     → $(grep '^PermitRootLogin' $SSH_CONFIG)"
    log "  PermitEmptyPasswords→ $(grep '^PermitEmptyPasswords' $SSH_CONFIG)"
    log "  MaxAuthTries        → $(grep '^MaxAuthTries' $SSH_CONFIG)"
    log "  X11Forwarding       → $(grep '^X11Forwarding' $SSH_CONFIG)"
    log "  ClientAliveInterval → $(grep '^ClientAliveInterval' $SSH_CONFIG)"
}


main() {
    mkdir -p "$REPORT_DIR"

    echo -e "${BLUE}"
    echo "============================================================"
    echo "   SSH HARDENING — Bastionado del Servicio SSH"
    echo "   Fecha: $(date '+%d/%m/%Y %H:%M:%S')"
    echo "============================================================"
    echo -e "${NC}"

    {
        echo "SSH HARDENING REPORT"
        echo "Fecha: $(date '+%d/%m/%Y %H:%M:%S')"
        echo "Sistema: $(hostname)"
    } > "$REPORT_FILE"

    check_ssh
    backup_config
    apply_hardening

    if verify_config; then
        restart_ssh
        show_summary
    fi

    log "\n${GREEN}============================================================"
    log "  ✔ SSH Hardening completado."
    log "  Backup en:  $BACKUP_FILE"
    log "  Reporte en: $REPORT_FILE"
    log "============================================================${NC}\n"
}
