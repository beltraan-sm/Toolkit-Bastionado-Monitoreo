#!/bin/bash
# ============================================================
#  firewall_audit.sh — Auditoría y bastionado del firewall
#  Compatible: Ubuntu 20.04 / 22.04 / 24.04
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

REPORT_DIR="$(dirname "$0")/../evidences"
REPORT_FILE="$REPORT_DIR/firewall_audit_$(date +%Y%m%d_%H%M%S).txt"

log() {
    echo -e "$1" | tee -a "$REPORT_FILE"
}

# ============================================================
# PASO 1 — Comprobar si UFW está instalado y activo
# ¿Qué es UFW? Es la herramienta de firewall de Ubuntu.
# Controla qué conexiones entran y salen del sistema.
# ============================================================
check_ufw() {
    log "\n${YELLOW}[1] ESTADO DEL FIREWALL (UFW)${NC}"
    log "------------------------------------------------------------"

    # Comprobamos si ufw está instalado
    if ! command -v ufw &>/dev/null; then
        log "${RED}  ✘ UFW no está instalado. Instalando...${NC}"
        apt-get install -y ufw &>/dev/null
        log "${GREEN}  ✔ UFW instalado.${NC}"
    fi

    # Comprobamos si está activo o no
    STATUS=$(ufw status | head -1)
    log "  Estado actual: ${YELLOW}$STATUS${NC}"

    if echo "$STATUS" | grep -q "inactive"; then
        log "${RED}  ⚠ El firewall está DESACTIVADO. Se activará tras aplicar reglas.${NC}"
    else
        log "${GREEN}  ✔ El firewall está activo.${NC}"
    fi
}

# ============================================================
# PASO 2 — Ver puertos abiertos actualmente
# ¿Por qué? Para saber qué servicios están escuchando
# conexiones antes de tocar nada.
# ============================================================
check_open_ports() {
    log "\n${YELLOW}[2] PUERTOS ABIERTOS ACTUALMENTE${NC}"
    log "------------------------------------------------------------"

    # ss lista los sockets activos del sistema
    # -tuln = TCP, UDP, en escucha, sin resolver nombres
    log "  Puertos en escucha (TCP/UDP):\n"
    ss -tuln | grep LISTEN | while read -r line; do
        log "    $line"
    done
}

# ============================================================
# PASO 3 — Aplicar reglas básicas de seguridad
# Política: denegar todo por defecto, permitir solo lo justo.
# ============================================================
apply_rules() {
    log "\n${YELLOW}[3] APLICANDO REGLAS DE SEGURIDAD${NC}"
    log "------------------------------------------------------------"

    # Denegar todo el tráfico entrante por defecto
    # ¿Por qué? Principio de mínimo privilegio: si no está permitido, bloqueado.
    ufw default deny incoming &>/dev/null
    log "${GREEN}  ✔ Política por defecto: DENEGAR tráfico entrante${NC}"

    # Permitir todo el tráfico saliente
    # ¿Por qué? El sistema necesita poder comunicarse hacia fuera (updates, DNS...).
    ufw default allow outgoing &>/dev/null
    log "${GREEN}  ✔ Política por defecto: PERMITIR tráfico saliente${NC}"

    # Permitir SSH (para no perder el acceso al servidor)
    # ¿Por qué? Si bloqueamos SSH y estamos conectados remotamente, nos quedamos fuera.
    ufw allow ssh &>/dev/null
    log "${GREEN}  ✔ Permitido: SSH (puerto 22)${NC}"

    # Activar UFW si no lo estaba
    ufw --force enable &>/dev/null
    log "${GREEN}  ✔ Firewall activado.${NC}"
}

# ============================================================
# PASO 4 — Mostrar las reglas activas tras los cambios
# ============================================================
show_rules() {
    log "\n${YELLOW}[4] REGLAS ACTIVAS TRAS EL BASTIONADO${NC}"
    log "------------------------------------------------------------"

    ufw status verbose | while read -r line; do
        log "  $line"
    done
}

# ============================================================
# FUNCIÓN PRINCIPAL
# ============================================================
main() {
    mkdir -p "$REPORT_DIR"

    echo -e "${BLUE}"
    echo "============================================================"
    echo "   FIREWALL AUDIT — Auditoría y Bastionado del Firewall"
    echo "   Fecha: $(date '+%d/%m/%Y %H:%M:%S')"
    echo "============================================================"
    echo -e "${NC}"

    {
        echo "FIREWALL AUDIT REPORT"
        echo "Fecha: $(date '+%d/%m/%Y %H:%M:%S')"
        echo "Sistema: $(hostname)"
    } > "$REPORT_FILE"

    check_ufw
    check_open_ports
    apply_rules
    show_rules

    log "\n${GREEN}============================================================"
    log "  ✔ Firewall Audit completado."
    log "  Reporte en: $REPORT_FILE"
    log "============================================================${NC}\n"
}

main