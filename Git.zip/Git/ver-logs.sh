#!/bin/bash
# ============================================================
#  log_monitor.sh — Análisis de logs de seguridad
#  Compatible: Ubuntu 20.04 / 22.04 / 24.04
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

REPORT_DIR="$(dirname "$0")/../evidences"
REPORT_FILE="$REPORT_DIR/log_monitor_$(date +%Y%m%d_%H%M%S).txt"

# En Ubuntu el log de autenticación puede estar en dos sitios
# dependiendo de la versión del sistema
if [ -f /var/log/auth.log ]; then
    AUTH_LOG="/var/log/auth.log"
else
    AUTH_LOG="/var/log/secure"
fi

log() {
    echo -e "$1" | tee -a "$REPORT_FILE"
}

# ============================================================
# PASO 1 — Comprobar que el log existe y es legible
# ============================================================
check_log() {
    log "\n${YELLOW}[1] COMPROBANDO ARCHIVO DE LOG${NC}"
    log "------------------------------------------------------------"

    if [ -f "$AUTH_LOG" ]; then
        LINES=$(wc -l < "$AUTH_LOG")
        log "${GREEN}  ✔ Log encontrado: $AUTH_LOG${NC}"
        log "  Total de líneas: $LINES"
    else
        log "${RED}  ✘ No se encontró el archivo de log.${NC}"
        exit 1
    fi
}

# ============================================================
# PASO 2 — Intentos de login fallidos
# ¿Por qué? Muchos fallos seguidos = ataque de fuerza bruta.
# ============================================================
check_failed_logins() {
    log "\n${YELLOW}[2] INTENTOS DE LOGIN FALLIDOS${NC}"
    log "------------------------------------------------------------"

    # grep busca líneas con "Failed password" en el log
    FAILED=$(grep "Failed password" "$AUTH_LOG" 2>/dev/null)
    COUNT=$(echo "$FAILED" | grep -c "Failed" 2>/dev/null)

    if [ "$COUNT" -eq 0 ]; then
        log "${GREEN}  ✔ No se encontraron intentos fallidos.${NC}"
    else
        log "${RED}  ⚠ Total de intentos fallidos: $COUNT${NC}"
        log "\n  Últimos 10 intentos:\n"
        echo "$FAILED" | tail -10 | while read -r line; do
            log "    $line"
        done
    fi
}

# ============================================================
# PASO 3 — IPs con más intentos fallidos
# ¿Por qué? Una IP con muchos intentos = posible atacante.
# ============================================================
check_suspicious_ips() {
    log "\n${YELLOW}[3] IPs CON MÁS INTENTOS FALLIDOS${NC}"
    log "------------------------------------------------------------"

    # grep saca las IPs de las líneas de fallo
    # sort + uniq -c las cuenta y ordena de mayor a menor
    IPS=$(grep "Failed password" "$AUTH_LOG" 2>/dev/null \
        | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' \
        | sort | uniq -c | sort -rn | head -10)

    if [ -z "$IPS" ]; then
        log "${GREEN}  ✔ No hay IPs sospechosas.${NC}"
    else
        log "  Top IPs atacantes:\n"
        echo "$IPS" | while read -r count ip; do
            log "    ${RED}$ip${NC} → $count intentos"
        done
    fi
}

# ============================================================
# PASO 4 — Logins exitosos
# ¿Por qué? Verificar que los accesos correctos son legítimos.
# ============================================================
check_successful_logins() {
    log "\n${YELLOW}[4] LOGINS EXITOSOS${NC}"
    log "------------------------------------------------------------"

    SUCCESS=$(grep "Accepted password\|Accepted publickey" "$AUTH_LOG" 2>/dev/null)
    COUNT=$(echo "$SUCCESS" | grep -c "Accepted" 2>/dev/null)

    if [ "$COUNT" -eq 0 ]; then
        log "  No se registraron logins exitosos recientes."
    else
        log "  Total de accesos correctos: ${GREEN}$COUNT${NC}"
        log "\n  Últimos 5 accesos:\n"
        echo "$SUCCESS" | tail -5 | while read -r line; do
            log "    ${GREEN}$line${NC}"
        done
    fi
}

# ============================================================
# PASO 5 — Usuarios que alguien intentó usar
# ¿Por qué? Detecta si alguien está probando usuarios
# que no existen o que no deberían usarse.
# ============================================================
check_targeted_users() {
    log "\n${YELLOW}[5] USUARIOS OBJETIVO DE ATAQUES${NC}"
    log "------------------------------------------------------------"

    USERS=$(grep "Failed password" "$AUTH_LOG" 2>/dev/null \
        | grep -oP 'for \K\S+' \
        | sort | uniq -c | sort -rn | head -10)

    if [ -z "$USERS" ]; then
        log "${GREEN}  ✔ No hay usuarios bajo ataque.${NC}"
    else
        log "  Usuarios más atacados:\n"
        echo "$USERS" | while read -r count user; do
            log "    ${YELLOW}$user${NC} → $count intentos"
        done
    fi
}

# ============================================================
# FUNCIÓN PRINCIPAL
# ============================================================
main() {
    mkdir -p "$REPORT_DIR"

    echo -e "${BLUE}"
    echo "============================================================"
    echo "   LOG MONITOR — Análisis de Logs de Seguridad"
    echo "   Fecha: $(date '+%d/%m/%Y %H:%M:%S')"
    echo "============================================================"
    echo -e "${NC}"

    {
        echo "LOG MONITOR REPORT"
        echo "Fecha: $(date '+%d/%m/%Y %H:%M:%S')"
        echo "Sistema: $(hostname)"
    } > "$REPORT_FILE"

    check_log
    check_failed_logins
    check_suspicious_ips
    check_successful_logins
    check_targeted_users

    log "\n${GREEN}============================================================"
    log "  ✔ Log Monitor completado."
    log "  Reporte en: $REPORT_FILE"
    log "============================================================${NC}\n"
}

main