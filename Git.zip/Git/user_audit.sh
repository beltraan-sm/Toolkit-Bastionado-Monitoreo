#!/bin/bash
# ============================================================
#  user_audit.sh — Auditoría de usuarios y permisos
#  Toolkit: Linux Security Toolkit
#  Compatible: Ubuntu 20.04 / 22.04 / 24.04
# ============================================================

# --- Colores para la terminal ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # Sin color (reset)

# --- Dónde se guarda el reporte ---
REPORT_DIR="$(dirname "$0")/../evidences"
REPORT_FILE="$REPORT_DIR/user_audit_$(date +%Y%m%d_%H%M%S).txt"

# ============================================================
# FUNCIÓN: Cabecera visual
# ============================================================
print_header() {
    echo -e "${BLUE}"
    echo "============================================================"
    echo "   USER AUDIT — Auditoría de Usuarios y Permisos"
    echo "   Fecha: $(date '+%d/%m/%Y %H:%M:%S')"
    echo "   Sistema: $(hostname)"
    echo "============================================================"
    echo -e "${NC}"
}

# ============================================================
# FUNCIÓN: Guardar en reporte + mostrar en pantalla
# ============================================================
log() {
    echo -e "$1" | tee -a "$REPORT_FILE"
}

# ============================================================
# SECCIÓN 1: Usuarios con shell activa
# ¿Por qué? Solo los usuarios con /bin/bash o /bin/sh
# pueden iniciar sesión. Los demás son cuentas de servicio.
# ============================================================
audit_shell_users() {
    log "\n${YELLOW}[1] USUARIOS CON SHELL ACTIVA (pueden iniciar sesión)${NC}"
    log "------------------------------------------------------------"

    # /etc/passwd tiene todos los usuarios. El último campo es la shell.
    # grep -v "/nologin\|/false" filtra los que NO pueden loguearse
    while IFS=: read -r username _ uid gid _ home shell; do
        if [[ "$shell" == */bash || "$shell" == */sh || "$shell" == */zsh ]]; then
            log "  Usuario: ${GREEN}$username${NC} | UID: $uid | Shell: $shell | Home: $home"
        fi
    done < /etc/passwd

    log ""
}

# ============================================================
# SECCIÓN 2: Usuarios SIN contraseña
# ¿Por qué? Un usuario sin contraseña es una puerta abierta.
# Cualquiera puede hacer 'su nombreusuario' sin escribir nada.
# ============================================================
audit_no_password() {
    log "\n${YELLOW}[2] USUARIOS SIN CONTRASEÑA (CRÍTICO)${NC}"
    log "------------------------------------------------------------"

    # /etc/shadow guarda los hashes de contraseñas
    # Si el campo de hash está vacío o es '!' = sin contraseña o bloqueado
    empty_pass=$(sudo awk -F: '($2 == "" || $2 == "!") {print $1}' /etc/shadow 2>/dev/null)

    if [ -z "$empty_pass" ]; then
        log "  ${GREEN}✔ No se encontraron usuarios sin contraseña.${NC}"
    else
        log "  ${RED}⚠ ALERTA — Usuarios sin contraseña detectados:${NC}"
        echo "$empty_pass" | while read -r user; do
            log "    → $user"
        done
    fi

    log ""
}

# ============================================================
# SECCIÓN 3: Usuarios con privilegios SUDO
# ¿Por qué? Sudo permite ejecutar comandos como root.
# Solo deben tenerlo las cuentas administradoras necesarias.
# ============================================================
audit_sudo_users() {
    log "\n${YELLOW}[3] USUARIOS CON PRIVILEGIOS SUDO${NC}"
    log "------------------------------------------------------------"

    # El grupo 'sudo' en Ubuntu da acceso a sudo
    sudo_users=$(getent group sudo | cut -d: -f4)

    if [ -z "$sudo_users" ]; then
        log "  ${GREEN}✔ Ningún usuario extra en el grupo sudo.${NC}"
    else
        log "  Usuarios en el grupo sudo:"
        echo "$sudo_users" | tr ',' '\n' | while read -r user; do
            log "    → ${YELLOW}$user${NC}"
        done
    fi

    # También revisamos /etc/sudoers.d/ por si hay reglas personalizadas
    log "\n  Reglas personalizadas en /etc/sudoers.d/:"
    if [ -d /etc/sudoers.d/ ]; then
        files=$(ls /etc/sudoers.d/ 2>/dev/null)
        if [ -z "$files" ]; then
            log "  ${GREEN}✔ No hay archivos extra en sudoers.d${NC}"
        else
            ls /etc/sudoers.d/ | while read -r f; do
                log "    → $f"
            done
        fi
    fi

    log ""
}

# ============================================================
# SECCIÓN 4: Archivos con permisos SUID/SGID
# ¿Por qué? SUID significa que el archivo se ejecuta con los
# permisos de su propietario (a veces root), aunque lo lance
# un usuario normal. Si hay SUID en sitios raros = peligro.
# ============================================================
============================================================
# SECCIÓN 5: Cuentas con UID 0 (root duplicado)
# ¿Por qué? Solo root debe tener UID=0. Si hay otro usuario
# con UID 0, tiene poderes de root aunque no se llame root.
# Eso es una backdoor clásica.
# ============================================================
audit_uid_zero() {
    log "\n${YELLOW}[5] CUENTAS CON UID 0 (equivalentes a root)${NC}"
    log "------------------------------------------------------------"

    uid0=$(awk -F: '($3 == 0) {print $1}' /etc/passwd)

    echo "$uid0" | while read -r user; do
        if [ "$user" = "root" ]; then
            log "  ${GREEN}✔ $user (UID 0 — normal)${NC}"
        else
            log "  ${RED}⚠ ALERTA — $user tiene UID 0 y NO es root!${NC}"
        fi
    done

    log ""
}

# ============================================================
# SECCIÓN 6: Últimos logins
# ¿Por qué? Ver quién se conectó últimamente ayuda a detectar
# accesos no autorizados o cuentas que no deberían usarse.
# ============================================================
audit_last_logins() {
    log "\n${YELLOW}[6] ÚLTIMOS ACCESOS AL SISTEMA${NC}"
    log "------------------------------------------------------------"

    last -n 10 | head -n 12 | while read -r line; do
        log "  $line"
    done

    log ""
}

# ============================================================
# FUNCIÓN PRINCIPAL — Ejecuta todas las secciones
# ============================================================
main() {
    # Crear directorio de evidencias si no existe
    mkdir -p "$REPORT_DIR"

    print_header

    echo -e "${BLUE}Iniciando auditoría... El reporte se guardará en:${NC}"
    echo -e "  ${GREEN}$REPORT_FILE${NC}\n"

    # Cabecera del reporte en texto plano
    {
        echo "============================================================"
        echo "   USER AUDIT REPORT"
        echo "   Fecha: $(date '+%d/%m/%Y %H:%M:%S')"
        echo "   Sistema: $(hostname)"
        echo "   Usuario ejecutor: $(whoami)"
        echo "============================================================"
    } > "$REPORT_FILE"

    # Ejecutar cada sección
    audit_shell_users
    audit_no_password
    audit_sudo_users
    audit_suid_sgid
    audit_uid_zero
    audit_last_logins

    log "\n${GREEN}============================================================"
    log "  ✔ Auditoría completada."
    log "  Reporte guardado en: $REPORT_FILE"
    log "============================================================${NC}\n"
}

# Punto de entrada
main